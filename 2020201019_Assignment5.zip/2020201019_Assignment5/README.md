## DS Assignment5
#### command to run programs: python pyspark_q[question no.].py numberOfCPUs(integer value) outputfilename
#### ex: for q1- python pyspark_q1.py 4 output1.txt